package com.zenika;

public interface Service {

	public String run();

}
