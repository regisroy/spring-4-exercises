package com.zenika.service;


public interface ManagementService {
    String doService();
}
