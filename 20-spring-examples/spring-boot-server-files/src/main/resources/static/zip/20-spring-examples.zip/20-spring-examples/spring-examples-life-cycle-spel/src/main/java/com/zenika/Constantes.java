package com.zenika;

public class Constantes {

    public static final String MESSAGE_TYPE_TEST = "TEST";
    public static final String MESSAGE_TYPE_PROD = "PROD";
    public static final String MESSAGE_TYPE_UAT = "UAT";
}
