package com.zenika.bean;

public interface Service {

	public String getElement();

	public void setElement(String element);

}
