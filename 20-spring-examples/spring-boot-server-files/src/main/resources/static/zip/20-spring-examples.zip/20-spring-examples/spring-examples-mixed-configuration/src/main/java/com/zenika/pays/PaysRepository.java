package com.zenika.pays;

import java.util.List;

public interface PaysRepository {
    List<Pays> findAll();
}
