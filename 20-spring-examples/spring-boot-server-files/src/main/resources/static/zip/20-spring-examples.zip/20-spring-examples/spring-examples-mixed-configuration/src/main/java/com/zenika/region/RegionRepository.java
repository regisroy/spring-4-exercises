package com.zenika.region;

public interface RegionRepository {
}
