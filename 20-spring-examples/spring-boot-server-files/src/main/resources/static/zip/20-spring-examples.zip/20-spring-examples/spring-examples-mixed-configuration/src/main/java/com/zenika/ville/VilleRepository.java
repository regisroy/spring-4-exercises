package com.zenika.ville;

public interface VilleRepository {
}
