package com.zenika.departement;

public interface DepartementRepository {
}
