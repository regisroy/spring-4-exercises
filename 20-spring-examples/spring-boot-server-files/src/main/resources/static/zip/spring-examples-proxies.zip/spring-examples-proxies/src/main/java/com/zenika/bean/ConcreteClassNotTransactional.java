package com.zenika.bean;

public class ConcreteClassNotTransactional {

    public String execute() {
        return "SUCCESS";
    }
}
