package com.zenika.training.spring.core.repo;

import com.zenika.training.spring.core.entity.Lettre;
import org.springframework.data.repository.CrudRepository;

public interface LettreRepository extends CrudRepository<Lettre, Long> {


}
