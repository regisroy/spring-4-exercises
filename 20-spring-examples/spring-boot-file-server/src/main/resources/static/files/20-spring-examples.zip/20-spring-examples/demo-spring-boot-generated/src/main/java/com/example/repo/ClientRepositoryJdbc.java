package com.example.repo;

import com.example.Client;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Repository
public class ClientRepositoryJdbc implements ClientRepository {
    private static final Logger log = LoggerFactory.getLogger(ClientRepositoryJdbc.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public List<Client> findAll() {
        log.info("Creating tables");

//        createTableAndInsertData();

        log.info("Querying for customer records where first_name = 'Josh':");

//        List<Client> clients = findByFirstName();

        List<Client> clients = findAllClients();

        clients.forEach(client -> log.info(client.toString()));

        return clients;
    }

    private List<Client> findAllClients() {
        return jdbcTemplate.query("SELECT id, first_name, last_name FROM client",
                    (rs, rowNum) -> new Client(rs.getLong("id"), rs.getString("first_name"), rs.getString("last_name")));
    }

    private List<Client> findByFirstName() {

        return jdbcTemplate.query("SELECT id, first_name, last_name FROM client WHERE first_name = ?",
                new Object[]{"Josh"},
                (rs, rowNum) -> new Client(rs.getLong("id"), rs.getString("first_name"), rs.getString("last_name")));
    }

    private void createTableAndInsertData() {
        jdbcTemplate.execute("DROP TABLE client IF EXISTS");
        jdbcTemplate.execute("CREATE TABLE client(id SERIAL, first_name VARCHAR(255), last_name VARCHAR(255))");

        // Split up the array of whole names into an array of first/last names
        List<Object[]> splitUpNames = Arrays.asList("John Woo", "Jeff Dean", "Josh Bloch", "Josh Long").stream()
                .map(name -> name.split(" "))
                .collect(Collectors.toList());

        // Use a Java 8 stream to print out each tuple of the list
        splitUpNames.forEach(name -> log.info(String.format("Inserting customer record for %s %s", name[0], name[1])));

        // Uses JdbcTemplate's batchUpdate operation to bulk load data
        jdbcTemplate.batchUpdate("INSERT INTO client(first_name, last_name) VALUES (?,?)", splitUpNames);
    }

}
