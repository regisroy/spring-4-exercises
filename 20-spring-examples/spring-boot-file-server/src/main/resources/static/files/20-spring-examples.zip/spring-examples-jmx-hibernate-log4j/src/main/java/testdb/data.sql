insert into LETTRE (ADRESSE1, ADRESSE2, ADRESSE3, CODE_POSTAL, VILLE) values ('Pierre DUPONT', '11 rue Anatole France', '', '05254', 'Tataouine');
insert into LETTRE (ADRESSE1, ADRESSE2, ADRESSE3, CODE_POSTAL, VILLE) values ('M. DUPONTEL', '22 bd Anatole France', '', '06000', 'Lyon');
insert into LETTRE (ADRESSE1, ADRESSE2, ADRESSE3, CODE_POSTAL, VILLE) values ('Mr. Henri MARTIN', '33 ave Anatole France', '', '07000', 'Munich');
insert into LETTRE (ADRESSE1, ADRESSE2, ADRESSE3, CODE_POSTAL, VILLE) values ('Catherine DUPAYS', '44 mail Anatole France', '', 'A8923', 'Edinbourg');