package com.zenika.training.spring.core;

public class ZipMain {

}
