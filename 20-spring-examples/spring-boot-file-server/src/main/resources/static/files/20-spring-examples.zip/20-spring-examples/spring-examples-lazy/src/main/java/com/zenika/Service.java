package com.zenika;

public interface Service {
	void whoAmI();
}
