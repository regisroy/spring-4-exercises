Spring 3 MVC and JSR303 @Valid example
======================================

http://www.mkyong.com/spring-mvc/spring-3-mvc-and-jsr303-valid-example/

Requirements
------------
* [Java Platform (JDK) 7](http://www.oracle.com/technetwork/java/javase/downloads/index.html)
* [Apache Maven 3.x](http://maven.apache.org/)

Quick start
-----------
1. `mvn jetty:run`
2. Point your browser to [http://localhost:8080/customer](http://localhost:8080/customer)