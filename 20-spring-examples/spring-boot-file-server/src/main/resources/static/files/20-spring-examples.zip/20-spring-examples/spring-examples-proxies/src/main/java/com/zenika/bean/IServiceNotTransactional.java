package com.zenika.bean;

public interface IServiceNotTransactional {

    public String doService();

}
