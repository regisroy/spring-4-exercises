insert into client(first_name,last_name) values ('Josh', 'Truman');
insert into client(first_name,last_name) values ('Josh', 'Welber');