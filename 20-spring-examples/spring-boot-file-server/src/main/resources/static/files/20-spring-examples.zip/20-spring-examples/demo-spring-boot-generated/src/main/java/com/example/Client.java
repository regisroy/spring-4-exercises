package com.example;

public class Client {
	private long id;

	private String firstName;
	private String lastName;

	public Client() {
	}

	public Client(long id, String firstName, String lastName) {
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setId(long id) {
		this.id = id;
	}

	public Client(String firstName) {
		this.id = 100;
		this.firstName = firstName;
	}

	public long getId() {
		return id;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}
}
