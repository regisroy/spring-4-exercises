package com.zenika.training.spring.core.service;

public interface LaPosteService {

    public void distribuer();
}
