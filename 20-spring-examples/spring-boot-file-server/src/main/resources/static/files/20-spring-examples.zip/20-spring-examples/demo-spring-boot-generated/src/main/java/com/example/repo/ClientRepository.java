package com.example.repo;


import com.example.Client;

import java.util.List;

public interface ClientRepository {

	List<Client> findAll();

}
