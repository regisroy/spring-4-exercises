package com.zenika.training.spring.core;

public interface PosteService {

    public void remettreLeCourrier();
}
