insert into client(first_name,last_name) values ('John', 'Doe');
insert into client(first_name,last_name) values ('Kent', 'Beck');