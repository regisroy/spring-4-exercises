package com.example.controller;

import com.example.Client;
import com.example.repo.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

@Controller
public class MonController {

    @Autowired
    ClientRepository clientRepository;

    @RequestMapping("/list")
    public String list(Model model) throws IOException {
        model.addAttribute("items", Arrays.asList("item 1", "item 2", "item 3"));

        System.out.println("\nmodel = " + model+"\n");

        return "list";
    }

    @RequestMapping("/clients")
    public String listClients(Model model) throws IOException {

        List<Client> clients = clientRepository.findAll();

        model.addAttribute("clients", clients);

        System.out.println("\nmodel = " + model+"\n");

        return "clients";
    }

}
