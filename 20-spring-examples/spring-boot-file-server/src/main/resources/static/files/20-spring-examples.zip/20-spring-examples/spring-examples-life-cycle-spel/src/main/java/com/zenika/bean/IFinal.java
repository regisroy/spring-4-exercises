package com.zenika.bean;

public interface IFinal {

	public abstract String getMessageType();

	public abstract void setMessageType(String messageType);

	public abstract String process();

}
