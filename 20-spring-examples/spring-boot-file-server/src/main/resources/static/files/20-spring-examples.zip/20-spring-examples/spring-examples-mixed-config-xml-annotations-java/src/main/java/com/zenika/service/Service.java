package com.zenika.service;

public interface Service {

    void execute();

}
