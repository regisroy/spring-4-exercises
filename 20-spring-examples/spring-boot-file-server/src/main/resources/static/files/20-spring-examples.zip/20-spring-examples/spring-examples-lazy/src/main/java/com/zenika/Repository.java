package com.zenika;

public interface Repository {

	void display();

}
