package com.zenika.training.spring.core;

public interface PosteNationale {

    public void distribuerLeCourrierDansTonPays();
}
