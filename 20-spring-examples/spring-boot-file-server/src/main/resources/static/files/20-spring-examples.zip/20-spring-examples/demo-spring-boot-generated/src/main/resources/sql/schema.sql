DROP TABLE client IF EXISTS;

CREATE TABLE client(id         SERIAL,
                    first_name VARCHAR(255),
                    last_name  VARCHAR(255)
);
