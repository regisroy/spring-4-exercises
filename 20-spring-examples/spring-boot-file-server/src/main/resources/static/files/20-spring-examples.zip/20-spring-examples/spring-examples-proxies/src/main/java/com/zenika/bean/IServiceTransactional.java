package com.zenika.bean;


public interface IServiceTransactional {

    public String executeTransactional();

}
